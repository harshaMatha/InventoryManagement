 function showBufferingLayer() {
            document.getElementById('buffering-layer').style.display = 'flex';
        }

        // Hide buffering layer
        function hideBufferingLayer() {
            document.getElementById('buffering-layer').style.display = 'none';
        }
$(document).ready(function () {
showBufferingLayer();
   $.ajax({
      url: "getProductCategories",
      method: "POST",
      dataType: "json",
      success: function (data) {
         console.log(data);

         // Populate options from response data
         data.forEach(function (category) {
            $("<option>").val(category.productCategoryId).text(category.productCategoryName).appendTo("#categorySelect");
         });
         hideBufferingLayer();
      },
      error: function () {
         console.log("Error");
      }
   })
});

$(document).ready(function () {
   $("#categorySelect").on("change", function () {
      var selectedCategoryId = $(this).val();
      var categoryId = {};
      categoryId["categoryId"] = selectedCategoryId;
      console.log(categoryId);
      showBufferingLayer();
      $.ajax({
         url: "getProductStockData",
         method: "POST",
         data: {
           categoryId : $(this).val()
         },
         success: function (data) {
            console.log(data);
            $("#productTableBody").empty();
            data.forEach(function (product) {
               var row = "<tr>";
               row += "<td>" + product.productId + "</td>";
               row += "<td>" + product.productName + "</td>";
               row += "<td>" + product.batchNo + "</td>";
               row += "<td>" + product.stock + "</td>";
               row += "<td>" + product.purchasePrice + "</td>";
               row += "<td>" + product.costPrice + "</td>";
               row += "<td>" + product.mrp + "</td>";
               row += "</tr>";

               $("#productTableBody").append(row);
            });
            hideBufferingLayer();
         },
         error: function () {
            console.log("Error");
         }
      });
   });
});