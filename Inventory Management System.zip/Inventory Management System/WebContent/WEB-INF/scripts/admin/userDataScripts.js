function showBufferingLayer() {
            document.getElementById('buffering-layer').style.display = 'flex';
        }

  // Hide buffering layer
 function hideBufferingLayer() {
            document.getElementById('buffering-layer').style.display = 'none';
        }
$(document).ready(function () {
   function applyFilter() {
      var userTypeFilter = $("#userTypeFilter").val();
      var userStatusFilter = $("#userStatusFilter").val();
      showBufferingLayer();
      $.ajax({
         url: "displayUsers",
         method: "POST",
         dataType: "json",
         data: {
            userType: userTypeFilter,
            userStatus: userStatusFilter
         },
         success: function (data) {
            // Handle the success response
            var userTableBody = $("#userTableBody");
            userTableBody.empty();

            data.forEach(function (user) {
               var row = $("<tr>");
               row.append($("<td>").text(user.userId));
               row.append($("<td>").text(user.userName));
               row.append($("<td>").text(user.userType));
               row.append($("<td>").text(user.status));
               userTableBody.append(row);
               hideBufferingLayer();
            });
         },
         error: function () {
            console.log("Error");
         }
      });
   }

   $("#applyFilterBtn").click(function () {
      applyFilter();
   });

   // Initial data load
   applyFilter();
});
$(document).ready(function () {
      showBufferingLayer();
      $.ajax({
         url: "showUsers",
         method: "POST",
         dataType: "json",
         success: function (data) {
            // Handle the success response
            var userTableBody = $("#userTableBody");
            userTableBody.empty();

            data.forEach(function (user) {
               var row = $("<tr>");
               row.append($("<td>").text(user.userId));
               row.append($("<td>").text(user.userName));
               row.append($("<td>").text(user.userType));
               row.append($("<td>").text(user.status));
               userTableBody.append(row);
               hideBufferingLayer();
            });
         },
         error: function () {
            console.log("Error");
         }
   });
});