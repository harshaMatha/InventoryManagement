package main.controllers;

import javax.persistence.LockTimeoutException;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.persistence.PessimisticLockException;
import javax.persistence.QueryTimeoutException;
import javax.persistence.TransactionRequiredException;

import org.hibernate.QueryException;
import org.hibernate.hql.internal.ast.QuerySyntaxException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import main.exceptions.UserAlreadyExists;

@ControllerAdvice
public class ExceptionHandlingController {

	private static final Logger logger = LoggerFactory.getLogger(ExceptionHandlingController.class);

	@ExceptionHandler(UserAlreadyExists.class)
	public ResponseEntity<String> handleUserAlreadyExists(UserAlreadyExists e) {
		logger.error("UserAlreadyExists exception occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(NoResultException.class)
	public ResponseEntity<String> handleNoResultException(NoResultException e) {
		logger.error("NoResultException occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(TransactionRequiredException.class)
	public ResponseEntity<String> handleTransactionRequiredException(TransactionRequiredException e) {
		logger.error("TransactionRequiredException occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(PersistenceException.class)
	public ResponseEntity<String> handlePersistenceException(PersistenceException e) {
		logger.error("PersistenceException occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception e) {
		logger.error("Exception occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(PessimisticLockException.class)
	public ResponseEntity<String> handlePessimisticLockException(PessimisticLockException e) {
		logger.error("PessimisticLockException occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(LockTimeoutException.class)
	public ResponseEntity<String> handleLockTimeoutException(LockTimeoutException e) {
		logger.error("LockTimeoutException occurred: {}", e.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}

	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<String> handleIllegalArgumentException(IllegalArgumentException ex) {
		logger.error("IllegalArgumentException occurred: {}", ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body("Invalid StoreIssueIds object provided: " + ex.getMessage());
	}

	@ExceptionHandler(QuerySyntaxException.class)
	public ResponseEntity<String> handleQuerySyntaxException(QuerySyntaxException ex) {
		logger.error("QuerySyntaxException occurred: {}", ex.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error in JPQL query syntax");
	}

	@ExceptionHandler(QueryTimeoutException.class)
	public ResponseEntity<String> handleQueryTimeoutException(QueryTimeoutException ex) {
		logger.error("QueryTimeoutException occurred: {}", ex.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body("Query execution timed out: " + ex.getMessage());
	}

	@ExceptionHandler(QueryException.class)
	public ResponseEntity<String> handleQueryException(QueryException ex) {
		logger.error("QueryException occurred: {}", ex.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
	}
}
