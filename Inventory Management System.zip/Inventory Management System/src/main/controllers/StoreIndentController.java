package main.controllers;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.dao.storeIndents.StoreIndentsDao;
import main.models.storeIssueModels.BLL.StoreIssuesBLL;
import main.models.storeIssueModels.InputModels.ProductId;
import main.models.storeIssueModels.InputModels.StoreIssuesList;
import main.models.storeIssueModels.entities.ProductsStock;
import main.models.storeIssueModels.entities.StoreIssues;
import main.models.storeIssueModels.outputModels.ProductOutput;
import main.models.storeModels.entities.StoreIndentData;
import main.models.storeModels.entities.StoreIndentsList;
import main.models.storeModels.inputmodels.IndentId;
import main.models.storeModels.inputmodels.StoreIndentsInputList;
import main.models.storeModels.outputmodels.StoreIds;
import main.models.storeModels.outputmodels.StoreIndentProducts;

@Controller
public class StoreIndentController {

	@Autowired
	StoreIndentsDao storeIndentsDao;
	@Autowired
	StoreIssuesBLL storeIssuesBLL;
	@Autowired
	ModelMapper modelMapper;
	ObjectMapper objectMapper = new ObjectMapper();

	@PostMapping("/getStoreIndentsList")
	public @ResponseBody List<StoreIndentData> getStoreIndentList(Model m) {
		System.out.println("indents");
		List<StoreIndentData> sl = storeIndentsDao.getStoreIndentsList();
		for (StoreIndentData s : sl)
			System.out.println(s);
		return sl;
	}

	@PostMapping("/getStoreIndentProductsList")
	public String getStoreIndentProductsList(String indentId, Model m) {
		System.out.println(indentId);
		IndentId indentid = null;
		try {
			indentid = objectMapper.readValue(indentId, IndentId.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		List<StoreIndentProducts> storeIndentProducts = storeIndentsDao.getStoreIndentsProductsList(indentid);

		// List<StoreIndentProducts> storeIndentProducts = new ArrayList();
		// for (StoreIndentProductsList s : storeIndentProductsList)
		// storeIndentProducts.add(modelMapper.map(s, StoreIndentProducts.class));
		//
		m.addAttribute("productsList", storeIndentProducts);

		for (StoreIndentProducts s : storeIndentProducts)
			System.out.println(s);

		return "store/storeIndentProducts";
	}

	@PostMapping("/newCreateStoreIndent")
	public String createStoreIndent(String jsonData, Model m) {
		// System.out.println("Data is " + jsonData);
		StoreIndentsInputList storeIndentsInputList = null;

		try {
			storeIndentsInputList = objectMapper.readValue(jsonData, StoreIndentsInputList.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		StoreIndentsList storeIndentsList = modelMapper.map(storeIndentsInputList, StoreIndentsList.class);

		// System.out.println(storeIndentsList);
		// m.addAttribute("data", storeIndentsList);

		storeIndentsDao.saveStoreIndent(storeIndentsList);

		return "store/createStoreIndent";
	}

	@PostMapping("/getIndentsListByStoreID")
	public @ResponseBody List<StoreIndentData> getIndentsList(@ModelAttribute("storeIds") StoreIds storeIds,
			Model model) {

		System.out.println(storeIds.getStoreId());

		System.out.println("hello");

		int selectedStoreId = storeIds.getStoreId();

		List<StoreIndentData> indents = storeIndentsDao.getIndentsByStoreID(selectedStoreId);
		System.out.println(indents);

		return indents;
	}

	@PostMapping("/getStoreIndentProductsListData")
	public @ResponseBody List<StoreIndentProducts> getStoreIndentProductsListData(String indentId, Model m) {
		System.out.println(indentId);
		IndentId indentid = null;
		try {
			indentid = objectMapper.readValue(indentId, IndentId.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		List<StoreIndentProducts> storeIndentProducts = storeIndentsDao.getStoreIndentsProductsList(indentid);

		return storeIndentProducts;
	}

	@PostMapping("/getBatchNumbers")
	public @ResponseBody List<ProductOutput> getBatchNumbers(@RequestBody ProductId productId) {
		System.out.println(productId);

		List<ProductsStock> productsStockList = storeIndentsDao.getBatchNumbers(productId);

		List<ProductOutput> productOutputList = new ArrayList<>();
		for (ProductsStock productsStock : productsStockList) {
			productOutputList.add(modelMapper.map(productsStock, ProductOutput.class));
		}

		return productOutputList;
	}

	@PostMapping("/issueStock")
	public String issueStock(@RequestBody StoreIssuesList storeIssuesList) {
		System.out.println(storeIssuesList);

        double totalPurchaseAmount = storeIssuesBLL.calculateTotalPurchaseAmount(storeIssuesList);
        
		StoreIssues storeIssues = modelMapper.map(storeIssuesList, StoreIssues.class);
		storeIssues.setAmount(totalPurchaseAmount);
		storeIndentsDao.saveStoreInfo(storeIssues);
		System.out.println("inserted successfull");
		return "inventory/inventoryHome";
	}

}
