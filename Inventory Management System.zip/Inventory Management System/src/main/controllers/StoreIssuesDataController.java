package main.controllers;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import main.dao.storeIssues.StoreIssueDao;
import main.models.storeIssueModels.BLL.StoreIssuesBLL;
import main.models.storeIssueModels.InputModels.ProductId;
import main.models.storeIssueModels.InputModels.StoreFilters;
import main.models.storeIssueModels.InputModels.StoreIssuesList;
import main.models.storeIssueModels.entities.ProductsStock;
import main.models.storeIssueModels.entities.StoreIssues;
import main.models.storeIssueModels.outputModels.ProductOutput;
import main.models.storeIssueModels.outputModels.StoreIssueId;
import main.models.storeIssueModels.outputModels.StoreIssueIds;
import main.models.storeIssueModels.outputModels.StoreIssueProducts;
import main.models.storeIssueModels.outputModels.StoreIssuesData;
import main.models.storeModels.inputmodels.StoreId;

@Controller
public class StoreIssuesDataController {

	@Autowired
	StoreIssueDao storeIssueDal;

	@Autowired
	StoreIssuesBLL storeIssuesBLL;

	@Autowired
	ModelMapper modelMapper;
	ObjectMapper objectMapper = new ObjectMapper();

	@GetMapping("/stockIssuesButton")
	public String getStockIssues() {
		return "inventory/stockIssues";
	}

	@PostMapping("/getBatchNumbers")
	public @ResponseBody List<ProductOutput> getBatchNumbers(@RequestBody ProductId productId) {
		System.out.println(productId);

		List<ProductsStock> productsStockList = storeIssueDal.getBatchNumbers(productId);

		List<ProductOutput> productOutputList = new ArrayList<>();
		for (ProductsStock productsStock : productsStockList) {
			productOutputList.add(modelMapper.map(productsStock, ProductOutput.class));
		}

		return productOutputList;
	}

	@PostMapping("/issueStock")
	public String issueStock(@RequestBody StoreIssuesList storeIssuesList) {
		System.out.println(storeIssuesList);

		double totalPurchaseAmount = storeIssuesBLL.calculateTotalPurchaseAmount(storeIssuesList);

		StoreIssues storeIssues = modelMapper.map(storeIssuesList, StoreIssues.class);
		storeIssues.setAmount(totalPurchaseAmount);
		System.out.println(storeIssues);
		storeIssueDal.saveStoreInfo(storeIssues);
		System.out.println("inserted successfull");
		return "inventory/inventoryHome";
	}

	// Getting StoreIssueIds
	@PostMapping("/getStoreIssueIds")
	public @ResponseBody List<StoreIssueId> getStoreIssueIds(StoreId sid, Model m) {
		System.out.println("store Id is : " + sid.getStoreId());
		List<StoreIssues> data = storeIssueDal.getStoreIds(sid);
		List<StoreIssueId> res = new ArrayList<>();
		for (StoreIssues s : data)
			res.add(modelMapper.map(data, StoreIssueId.class));
		return res;
	}

	// Getting StoreIssues List
	@PostMapping("/getStoreIssuesList")
	@ResponseBody
	public List<StoreIssuesData> getStoreIssues(Model m) {

		List<StoreIssuesData> storeIssuesDataList = storeIssueDal.getAllStoreIssues();

		return storeIssuesDataList;
	}

	// Getting StoreIssue Products List
	@PostMapping("/getStoreIssueProductsList")
	public String getStoreIndentProductsList(String storeIssueId, Model m) {
		System.out.println(storeIssueId);
		StoreIssueIds storeIssueIds = null;
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			storeIssueIds = objectMapper.readValue(storeIssueId, StoreIssueIds.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		List<StoreIssueProducts> storeIssueProduct = storeIssueDal.getStoreIssuesProductsList(storeIssueIds);

		m.addAttribute("productsList", storeIssueProduct);
		return "inventory/stockIssuedProducts";
	}

	/* Filters */
	@PostMapping("/getIssuesFilterDataIdStatusFrom")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataIdStatusFrom(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByIdStatusFrom(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataIdStatus")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataIdStatus(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByIdStatus(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataIdFrom")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataIdFrom(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByIdFrom(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataId")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataId(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListById(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataStatusFrom")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataStatusFrom(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByStatusFrom(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataStatus")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataStatus(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByStatus(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataFrom")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataFrom(String filters, Model m) {
		StoreFilters storeFilters = null;
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByFrom(storeFilters);
		return sl;
	}

	@PostMapping("/getIssuesFilterDataTo")
	public @ResponseBody List<StoreIssuesData> getIssuesFilterDataTo(String filters, Model m) {
		StoreFilters storeFilters = null;
		System.out.println("Inside to");
		objectMapper.registerModule(new JavaTimeModule());
		try {
			storeFilters = objectMapper.readValue(filters, StoreFilters.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<StoreIssuesData> sl = storeIssueDal.getStoreIssuesListByTo(storeFilters);
		return sl;
	}

}
