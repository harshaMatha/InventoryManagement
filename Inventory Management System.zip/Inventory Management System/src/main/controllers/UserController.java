package main.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.dao.users.WarehouseUsersDAO;
import main.models.userModels.entities.User;
import main.models.userModels.inputModels.UserData;
import main.models.userModels.inputModels.UserId;
import main.models.userModels.inputModels.UserTypeStatus;
import main.models.userModels.outputModels.UserIds;
import main.models.userModels.outputModels.UserInfo;
import main.models.userModels.outputModels.UserType;
import main.service.admin.UserService;

@Controller
public class UserController {

	private final WarehouseUsersDAO userDAO;
	private final ModelMapper mapper;
	private final UserService userService;

	@Autowired
	public UserController(WarehouseUsersDAO userDAO, ModelMapper mapper, UserService userService) {
		this.userDAO = userDAO;
		this.mapper = mapper;
		this.userService = userService;
	}

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	// Saving user
	@PostMapping("/saveUser")
	public String saveUser(@RequestBody String data, Model model) throws Exception {
		logger.info("Received request to save user");

		UserData userData = null;
		// Object mapper for JSON serialization/deserialization
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			logger.debug("Deserializing JSON to UserData object");
			// Deserialize the JSON string to UserData object
			userData = objectMapper.readValue(data, UserData.class);
		} catch (JsonMappingException e) {
			logger.error("Error occurred while deserializing JSON to UserData object", e);
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			logger.error("Error occurred during JSON processing", e);
			e.printStackTrace();
		}

		logger.debug("Mapping UserData to User using ModelMapper");
		// Map UserData to User using ModelMapper
		User user = mapper.map(userData, User.class);

		logger.debug("Saving User object using userDAO");
		// Save the User object using userDAO
		userDAO.saveUser(user);
		logger.info("User saved successfully");

		return "admin/adminHome";
	}

	// Getting User Type
	@PostMapping("/getUser")
	public @ResponseBody List<UserType> deleteUser(Model model) throws Exception {
		logger.info("Received request to get all users");
		// Retrieve all users from the database using userDAO
		List<User> users = userDAO.getAllUsers();

		logger.debug("Mapping User objects to UserType using ModelMapper");
		// Map each User object to UserType using ModelMapper and collect into a list
		List<UserType> userType = users.stream().map(user -> mapper.map(user, UserType.class))
				.collect(Collectors.toList());

		logger.info("Returning all users");
		// Return the list of UserType objects as a JSON response
		return userType;
	}

	// Getting User Id and User Name
	@RequestMapping(value = "/getUserData", method = RequestMethod.POST)
	public @ResponseBody List<UserIds> getUserData(@RequestBody Map<String, String> request) throws Exception {

		// Extract the userType from the request
		String userType = request.get("userType");
		logger.info("Received request to retrieve user data for userType: {}", userType);

		// Retrieve all active users from the database using userDAO
		List<User> users = userDAO.getAllActiveUsers();
		logger.info("Retrieved {} active users from the database", users.size());

		// Create a list to store the UserIds objects
		List<UserIds> userIds = new ArrayList<>();

		// Iterate through each user and check if userType matches
		for (User user : users) {
			if (userType.equals(user.getUserType())) {
				// Create a new UserIds object and set the userId and userName
				UserIds userId = new UserIds();
				userId.setUserId(user.getUserId());
				userId.setUserName(user.getUserName());

				// Add the UserIds object to the list
				userIds.add(userId);
			}
		}

		logger.info("Processed user data for userType: {}. Total matching users: {}", userType, userIds.size());

		return userIds; // Return the list of UserIds objects as a JSON response
	}

	// Deleting User
	@PostMapping("/deleteUserData")
	public String deleteUser(@RequestBody UserId user) throws Exception {
		// Logger for logging statements

		logger.info("Received request to delete user with userId: {}", user.getUserId());
		// Delete the user based on the given UserId using userDAO
		userDAO.deleteUser(user);

		logger.info("User with userId: {} deleted successfully", user.getUserId());

		return "admin/success";
	}

	@PostMapping("/showUsers")
	@ResponseBody
	public List<UserInfo> displayUsers() throws Exception {
		// Retrieve all users from the database using userDAO
		List<User> users = userDAO.getAllUsers();

		// Map each User object to UserInfo using ModelMapper and collect into a list
		List<UserInfo> userInfo = users.stream().map(user -> mapper.map(user, UserInfo.class))
				.collect(Collectors.toList());

		logger.info("Retrieved {} users from the database.", users.size());
		// Return the list of UserInfo objects as a JSON response
		return userInfo;
	}

	/* Filters */
	@PostMapping("/displayUsers")
	public @ResponseBody List<UserTypeStatus> getByTypeStatus(UserTypeStatus userTypeStatus) {
		logger.info("Received request to retrieve users with filters: {}", userTypeStatus);

		// Get the list of UserTypeStatus objects based on the provided filters
		List<UserTypeStatus> userTypeStatusList = userService.getUserFilters(userTypeStatus);

		logger.info("Retrieved {} user(s) with filters: {}", userTypeStatusList.size(), userTypeStatus);

		return userTypeStatusList;
	}

}
