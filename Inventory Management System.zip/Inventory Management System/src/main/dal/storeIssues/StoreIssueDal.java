package main.dal.storeIssues;

import java.util.List;
import java.util.NoSuchElementException;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.QueryTimeoutException;
import javax.persistence.TransactionRequiredException;
import javax.transaction.Transactional;

import org.hibernate.QueryException;
import org.hibernate.hql.internal.ast.QuerySyntaxException;
import org.springframework.stereotype.Component;

import main.dao.storeIssues.StoreIssueDao;
import main.exceptions.InSufficientStockException;
import main.models.productModels.entities.ProductStock;
import main.models.productModels.inputModels.ProductsProductIdInputModel;
import main.models.storeIssueModels.entities.StoreIssueData;
import main.models.storeIssueModels.entities.StoreIssues;
import main.models.storeIssueModels.inputModels.StoreFilters;
import main.models.storeIssueModels.outputModels.StoreIssueIds;
import main.models.storeIssueModels.outputModels.StoreIssueProducts;
import main.models.storeIssueModels.outputModels.StoreIssuesData;
import main.models.storeModels.inputmodels.StoreId;

@Component
public class StoreIssueDal implements StoreIssueDao {

	@PersistenceContext
	EntityManager entityManager;

	// Getting StoreIssue Information Based on storeID
	@Override
	@Transactional
	public List<StoreIssueData> getStoreIds(StoreId storeId) throws Exception {
		int storeIds = storeId.getStoreId();
		try {
			List<StoreIssueData> data = entityManager
					.createQuery("select s from StoreIssueData s where s.storeId = :id", StoreIssueData.class)
					.setParameter("id", storeIds).getResultList();

			return data; // Returning StoreIssueId, storeIssueDate, storeIssueStatus, amount
		} catch (NoResultException ex) {
			throw new NoResultException("No result found for storeId: " + storeIds);
		} catch (TransactionRequiredException ex) {
			throw new TransactionRequiredException("Transaction is required for retrieving store issue data");
		} catch (PersistenceException ex) {
			throw new PersistenceException("Error retrieving store issue data", ex);
		} catch (Exception ex) {
			throw new Exception("An error occurred while retrieving store issue data", ex);
		}
	}

	// Getting all StoreIssue Infromation
	@Override
	@Transactional
	public List<StoreIssuesData> getAllStoreIssues() throws Exception {
		try {
			List<StoreIssuesData> storeIssue = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p",
					StoreIssuesData.class).getResultList();

			return storeIssue;
		} catch (TransactionRequiredException ex) {
			throw new TransactionRequiredException("Transaction is required for retrieving store issues data");
		} catch (NoResultException ex) {
			throw new NoResultException("No result found for store issues");
		} catch (PersistenceException ex) {
			throw new PersistenceException("Error retrieving store issues data", ex);
		}
	}

	// Getting StoreIssue Products Information
	@Override
	public List<StoreIssueProducts> getStoreIssuesProductsList(StoreIssueIds storeIssueIds) throws Exception {
		try {
			int storeIssueId = storeIssueIds.getStoreIssueId();
			List<StoreIssueProducts> storeIssueProducts = entityManager.createQuery(
					"SELECT NEW main.models.storeIssueModels.outputModels.StoreIssueProducts(e.productId,e.batchNo, p.productName, pc.productCategoryName, e.issuedQuantity) "
							+ "FROM main.models.storeIssueModels.entities.StoreIssueProduct e "
							+ "JOIN main.models.productModels.entities.Products p ON e.productId = p.productId "
							+ "JOIN main.models.productModels.entities.ProductsCategory pc ON p.category = pc.productCategoryId "
							+ "WHERE e.storeIssueId = :data",
					StoreIssueProducts.class) // Change the result type here
					.setParameter("data", storeIssueId).getResultList();

			return storeIssueProducts;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreIssueIds object provided", ex);
		} catch (QuerySyntaxException ex) {
			throw new QuerySyntaxException("Error in JPQL query syntax");
		} catch (PersistenceException ex) {
			throw new PersistenceException("Error retrieving store issue products data", ex);
		} catch (Exception ex) {
			throw new Exception("An error occurred while retrieving store issue products data", ex);
		}
	}

	// Getting Filtered Data based on To date
	@Override
	public List<StoreIssuesData> getStoreIssuesListByTo(StoreFilters storeFilters) throws Exception {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p where p.storeIssueDate<=:toDate")
					.setParameter("toDate", storeFilters.getToDate()).getResultList();

			return listStoreIssues;
		} catch (TransactionRequiredException ex) {
			throw new TransactionRequiredException("Transaction is required for retrieving store issues data");
		} catch (QueryTimeoutException ex) {
			throw new QueryTimeoutException("Query execution timed out", ex);
		} catch (NonUniqueResultException ex) {
			throw new NonUniqueResultException("Multiple results found for store issues");
		} catch (NoResultException ex) {
			throw new NoResultException("No result found for store issues");
		} catch (PersistenceException ex) {
			throw new PersistenceException("Error retrieving store issues data", ex);
		}
	}

	// Getting Filtered Data Based on from Date,To date
	@Override
	public List<StoreIssuesData> getStoreIssuesListByFrom(StoreFilters storeFilters) throws Exception {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p where p.storeIssueDate>=:fromDate and p.storeIssueDate<=:toDate")
					.setParameter("fromDate", storeFilters.getFromDate())
					.setParameter("toDate", storeFilters.getToDate()).getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object provided", ex);
		} catch (QueryTimeoutException ex) {
			throw new QueryTimeoutException("Query execution timed out", ex);
		}
	}

	// Getting Filtered Information based on StoreIssueStatus,To date
	@Override
	public List<StoreIssuesData> getStoreIssuesListByStatus(StoreFilters storeFilters) throws Exception {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p where p.storeIssueStatus=:storeIssueStatus and p.storeIssueDate<=:toDate")
					.setParameter("storeIssueStatus", storeFilters.getStoreIssueStatus())
					.setParameter("toDate", storeFilters.getToDate()).getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object provided", ex);
		} catch (QueryException ex) {
			throw new Exception("Error executing the query", ex);
		} catch (PersistenceException ex) {
			throw new Exception("Error accessing the database", ex);
		} catch (Exception ex) {
			throw new Exception("An unexpected error occurred", ex);
		}
	}

	// Getting Filtered Information based on StoreIssueStatus,From date,To date
	@Override
	public List<StoreIssuesData> getStoreIssuesListByStatusFrom(StoreFilters storeFilters) throws Exception {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId)"
							+ " from StoreIssue p "
							+ "where p.storeIssueDate<=:toDate and p.storeIssueDate>=:fromDate and p.storeIssueStatus=:storeIssueStatus")
					.setParameter("storeIssueStatus", storeFilters.getStoreIssueStatus())
					.setParameter("toDate", storeFilters.getToDate())
					.setParameter("fromDate", storeFilters.getFromDate()).getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object provided", ex);
		} catch (QueryException ex) {
			throw new Exception("Error executing the query", ex);
		} catch (PersistenceException ex) {
			throw new Exception("Error accessing the database", ex);
		} catch (Exception ex) {
			throw new Exception("An unexpected error occurred", ex);
		}
	}

	// Getting Filtered data based on StoreID
	@Override
	public List<StoreIssuesData> getStoreIssuesListById(StoreFilters storeFilters) throws Exception {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p where p.storeId=:storeId and p.storeIssueDate<=:toDate")
					.setParameter("storeId", storeFilters.getStoreId()).setParameter("toDate", storeFilters.getToDate())
					.getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object or parameters provided.", ex);
		} catch (NoResultException ex) {
			throw new NoResultException("No store issues found for the given storeId and toDate.");
		} catch (NonUniqueResultException ex) {
			throw new IllegalStateException("Multiple store issues found for the given storeId and toDate.", ex);
		}
	}

	// Getting Filtered Information based on StoreId,From date
	@Override
	public List<StoreIssuesData> getStoreIssuesListByIdFrom(StoreFilters storeFilters) {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p where p.storeId=:storeId and p.storeIssueDate<=:toDate and p.storeIssueDate>=:fromDate")
					.setParameter("storeId", storeFilters.getStoreId())
					.setParameter("fromDate", storeFilters.getFromDate())
					.setParameter("toDate", storeFilters.getToDate()).getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object or parameters provided.", ex);
		} catch (NoResultException ex) {
			throw new NoSuchElementException("No store issues found for the given storeId, fromDate, and toDate.");
		} catch (NonUniqueResultException ex) {
			throw new IllegalStateException("Multiple store issues found for the given storeId, fromDate, and toDate.",
					ex);
		}
	}

	// Getting Filtered Information based on storeId,StoreIssue Status
	@Override
	public List<StoreIssuesData> getStoreIssuesListByIdStatus(StoreFilters storeFilters) {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId) from StoreIssue p where p.storeId=:storeId and p.storeIssueDate<=:toDate and p.storeIssueStatus=:storeIssueStatus")
					.setParameter("storeId", storeFilters.getStoreId())
					.setParameter("storeIssueStatus", storeFilters.getStoreIssueStatus())
					.setParameter("toDate", storeFilters.getToDate()).getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object or parameters provided.", ex);
		} catch (NoResultException ex) {
			throw new NoSuchElementException(
					"No store issues found for the given storeId, toDate, and storeIssueStatus.");
		} catch (NonUniqueResultException ex) {
			throw new IllegalStateException(
					"Multiple store issues found for the given storeId, toDate, and storeIssueStatus.", ex);
		}
	}

	// Getting Filtered Information based on StoreId,StoreIssue Status,From Date
	@Override
	public List<StoreIssuesData> getStoreIssuesListByIdStatusFrom(StoreFilters storeFilters) {
		try {
			List<StoreIssuesData> listStoreIssues = entityManager.createQuery(
					"select new main.models.storeIssueModels.outputModels.StoreIssuesData(p.storeIssueId,p.storeIssueDate,p.amount,p.storeIssueStatus,p.storeId)"
							+ " from StoreIssue p "
							+ "where p.storeIssueDate<=:toDate and p.storeIssueDate>=:fromDate and p.storeId=:storeId and p.storeIssueStatus=:storeIssueStatus")
					.setParameter("storeId", storeFilters.getStoreId())
					.setParameter("storeIssueStatus", storeFilters.getStoreIssueStatus())
					.setParameter("toDate", storeFilters.getToDate())
					.setParameter("fromDate", storeFilters.getFromDate()).getResultList();
			return listStoreIssues;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid StoreFilters object or parameters provided.", ex);
		} catch (NoResultException ex) {
			throw new NoSuchElementException(
					"No store issues found for the given storeId, fromDate, toDate, and storeIssueStatus.");
		} catch (NonUniqueResultException ex) {
			throw new IllegalStateException(
					"Multiple store issues found for the given storeId, fromDate, toDate, and storeIssueStatus.", ex);
		}
	}

	// Getting PRoductStock Information based on ProductId
	@Override
	@Transactional
	public List<ProductStock> getBatchNumbers(ProductsProductIdInputModel productId) {
		try {
			List<ProductStock> productStock = entityManager
					.createQuery("SELECT p FROM ProductStock p WHERE p.productId = :productId", ProductStock.class)
					.setParameter("productId", productId.getProductId()).getResultList();
			return productStock;
		} catch (IllegalArgumentException ex) {
			throw new IllegalArgumentException("Invalid ProductsProductIdInputModel object or parameters provided.",
					ex);
		} catch (NoResultException ex) {
			throw new NoSuchElementException("No product stocks found for the given productId.");
		}
	}

	// Saving StoreIssue Information
	@Override
	@Transactional
	public boolean saveStoreInfo(StoreIssues storeIssues) throws Exception {
		try {
			// Set the status of the storeIssues object to "Approved"
			storeIssues.setStatus("Approved");
			// Save the storeIssues object in the database
			entityManager.persist(storeIssues);
			// Retrieve the list of StoreIssueProducts associated with the storeIssues object
			List<main.models.storeIssueModels.entities.StoreIssueProducts> storeIssueProductsList = storeIssues
					.getStoreProducts();

			for (main.models.storeIssueModels.entities.StoreIssueProducts storeIssueProducts : storeIssueProductsList) {
				// Set the storeIssueId for each StoreIssueProducts object
				storeIssueProducts.setStoreIssueId(storeIssues.getStoreIssueId());
				// Set the relationship with the saved StoreIssues instance
				storeIssueProducts.setStoreIssues(storeIssues);
				// Save each StoreIssueProducts object in the database
				entityManager.persist(storeIssueProducts);

				// Retrieve the ProductStock object associated with the productId and batchNo of the StoreIssueProducts
				ProductStock productStock = entityManager
						.createQuery("SELECT e FROM ProductStock e WHERE e.productId=:productId AND e.batchNo=:batchNo",
								ProductStock.class)
						.setParameter("productId", storeIssueProducts.getProductId())
						.setParameter("batchNo", storeIssueProducts.getBatchNo()).getSingleResult();

				// Retrieve the current product stock quantity
				int productsStock = productStock.getProductStock();
				// Retrieve the issued quantity from the StoreIssueProducts object
				int issuedQuantity = storeIssueProducts.getQuantity();

				// Check if there is sufficient product stock
				if (productsStock >= issuedQuantity) {
					// Update the product stock quantity
					productStock.setProductStock(productsStock - issuedQuantity);
				} else {
					// Throw an exception if there is insufficient product stock
					throw new InSufficientStockException("Insufficient product stock for productId:");
				}
			}

			// Return true if the storeIssues and associated StoreIssueProducts are successfully saved
			return true;
		} catch (IllegalArgumentException ex) {
			// Throw an exception for invalid StoreIssues object or parameters provided
			throw new IllegalArgumentException("Invalid StoreIssues object or parameters provided.", ex);
		} catch (NoResultException ex) {
			// Throw an exception if no ProductStock found for the given productId and batchNo
			throw new NoSuchElementException("No ProductStock found for the given productId and batchNo.");
		} catch (Exception ex) {
			ex.printStackTrace();
			// Print the stack trace if any other exception occurs
			return false;
		}
	}

}
