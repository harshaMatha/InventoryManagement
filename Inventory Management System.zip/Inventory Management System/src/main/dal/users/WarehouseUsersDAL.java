package main.dal.users;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockTimeoutException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.PessimisticLockException;
import javax.persistence.QueryTimeoutException;
import javax.persistence.TransactionRequiredException;
import javax.transaction.Transactional;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import main.dao.users.WarehouseUsersDAO;
import main.exceptions.UserAlreadyExists;
import main.models.userModels.entities.User;
import main.models.userModels.inputModels.UserId;
import main.models.userModels.inputModels.UserTypeStatus;

@Component
public class WarehouseUsersDAL implements WarehouseUsersDAO {

	@PersistenceContext
	private EntityManager entityManager;

	// Saving Warehouse User Information
	@Transactional
	public void saveUser(User user) throws Exception {
		String userName = user.getUserName();
		if (userExists(userName)) {
			throw new UserAlreadyExists("User with the same unique key already exists.");
		} else {
			try {
				entityManager.persist(user); // Save the User object in the database
			} catch (IllegalArgumentException ex) {
				ex.printStackTrace();
				throw new IllegalArgumentException("Error saving user: Invalid argument or parameter.", ex);
			} catch (PersistenceException ex) {
				ex.printStackTrace();
				throw new PersistenceException("Error saving user: Database error occurred.", ex);
			}
		}
	}

	@Transactional
	private boolean userExists(String userName) throws Exception {
		try {
			// Check if a user with the given userName already exists
			long count = entityManager
					.createQuery("SELECT COUNT(u) FROM User u WHERE u.userName = :userName", Long.class)
					.setParameter("userName", userName).getSingleResult();
			return count > 0;
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new PersistenceException("Error accessing data: Database error occurred.", ex);
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		}
	}

	// Soft Deleting the Warehouse Users
	@Override
	@Transactional
	public User deleteUser(UserId user) throws Exception {
		try {
			// Find the User object with the given userId
			User existingUser = entityManager.find(User.class, user.getUserId());

			// Set the status of the existing User object to "Inactive"
			existingUser.setStatus("Inactive");
			// Merge the changes into the database
			entityManager.merge(existingUser);

			return existingUser; // Return the updated User object
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		} catch (TransactionRequiredException ex) {
			ex.printStackTrace();
			throw new TransactionRequiredException("Error accessing data: Transaction required.");
		}
	}

	// Getting all Active Warehouse Users
	@Override
	@Transactional
	public List<User> getAllActiveUsers() throws Exception {
		try {
			// Retrieve all User objects with status "active"
			List<User> users = entityManager.createQuery("SELECT u FROM User u WHERE u.status = 'active'", User.class)
					.getResultList();
			return users;
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		} catch (QueryTimeoutException ex) {
			ex.printStackTrace();
			throw new QueryTimeoutException("Error accessing data: Query timeout occurred.", ex);
		} catch (TransactionRequiredException ex) {
			ex.printStackTrace();
			throw new TransactionRequiredException("Error accessing data: Transaction required.");
		} catch (PessimisticLockException ex) {
			ex.printStackTrace();
			throw new PessimisticLockException("Error accessing data: Pessimistic lock exception occurred.", ex);
		} catch (LockTimeoutException ex) {
			ex.printStackTrace();
			throw new LockTimeoutException("Error accessing data: Lock timeout occurred.", ex);
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new PersistenceException("Error accessing data: Persistence exception occurred.", ex);
		}
	}

	// Getting all Warehouse Users
	@Override
	@Transactional
	public List<User> getAllUsers() throws Exception {
		try {
			// Retrieve all User objects from the database
			List<User> listUsers = entityManager.createQuery("SELECT u FROM User u", User.class).getResultList();
			return listUsers;
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		} catch (QueryTimeoutException ex) {
			ex.printStackTrace();
			throw new QueryTimeoutException("Error accessing data: Query timeout occurred.", ex);
		} catch (TransactionRequiredException ex) {
			ex.printStackTrace();
			throw new TransactionRequiredException("Error accessing data: Transaction required.");
		} catch (PessimisticLockException ex) {
			ex.printStackTrace();
			throw new PessimisticLockException("Error accessing data: Pessimistic lock exception occurred.", ex);
		} catch (LockTimeoutException ex) {
			ex.printStackTrace();
			throw new LockTimeoutException("Error accessing data: Lock timeout occurred.", ex);
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new PersistenceException("Error accessing data: Persistence exception occurred.", ex);
		}
	}

	// Getting User data based on the selected user type and status
	@Override
	@Transactional
	public List<UserTypeStatus> getUserByTypeStatus(UserTypeStatus userTypeStatus) throws Exception {
		try {
			List<UserTypeStatus> userTypeStatusList = entityManager
					.createQuery("SELECT u FROM User u WHERE u.status = :userStatus AND u.userType = :userType",
							UserTypeStatus.class)
					.setParameter("userStatus", userTypeStatus.getUserStatus())
					.setParameter("userType", userTypeStatus.getUserType()).getResultList();
			return userTypeStatusList;
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		} catch (QueryTimeoutException ex) {
			ex.printStackTrace();
			throw new QueryTimeoutException("Error accessing data: Query timeout occurred.", ex);
		} catch (TransactionRequiredException ex) {
			ex.printStackTrace();
			throw new TransactionRequiredException("Error accessing data: Transaction required.");
		} catch (PessimisticLockException ex) {
			ex.printStackTrace();
			throw new PessimisticLockException("Error accessing data: Pessimistic lock exception occurred.", ex);
		} catch (LockTimeoutException ex) {
			ex.printStackTrace();
			throw new LockTimeoutException("Error accessing data: Lock timeout occurred.", ex);
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new PersistenceException("Error accessing data: Persistence exception occurred.", ex);
		}
	}

	// Getting user data based on UserStatus
	@Override
	@Transactional
	public List<UserTypeStatus> getFilteredDataByStatus(UserTypeStatus userTypeStatus) throws Exception {
		try {
			List<UserTypeStatus> userTypeStatusList = entityManager
					.createQuery("SELECT u FROM User u WHERE u.status = :userStatus", UserTypeStatus.class)
					.setParameter("userStatus", userTypeStatus.getUserStatus()).getResultList();
			return userTypeStatusList;
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		} catch (QueryTimeoutException ex) {
			ex.printStackTrace();
			throw new QueryTimeoutException("Error accessing data: Query timeout occurred.", ex);
		} catch (TransactionRequiredException ex) {
			ex.printStackTrace();
			throw new TransactionRequiredException("Error accessing data: Transaction required.");
		} catch (PessimisticLockException ex) {
			ex.printStackTrace();
			throw new PessimisticLockException("Error accessing data: Pessimistic lock exception occurred.", ex);
		} catch (LockTimeoutException ex) {
			ex.printStackTrace();
			throw new LockTimeoutException("Error accessing data: Lock timeout occurred.", ex);
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new PersistenceException("Error accessing data: Persistence exception occurred.", ex);
		}
	}

	// Getting user Data based on userType
	@Override
	@Transactional
	public List<UserTypeStatus> getFilteredDataByType(UserTypeStatus userTypeStatus) throws DataAccessException {
		try {
			List<UserTypeStatus> userTypeStatusList = entityManager
					.createQuery("SELECT u FROM User u WHERE u.userType = :userType", UserTypeStatus.class)
					.setParameter("userType", userTypeStatus.getUserType()).getResultList();
			return userTypeStatusList;
		} catch (IllegalArgumentException ex) {
			ex.printStackTrace();
			throw new IllegalArgumentException("Error accessing data: Invalid argument or parameter.", ex);
		} catch (QueryTimeoutException ex) {
			ex.printStackTrace();
			throw new QueryTimeoutException("Error accessing data: Query timeout occurred.", ex);
		} catch (TransactionRequiredException ex) {
			ex.printStackTrace();
			throw new TransactionRequiredException("Error accessing data: Transaction required.");
		} catch (PessimisticLockException ex) {
			ex.printStackTrace();
			throw new PessimisticLockException("Error accessing data: Pessimistic lock exception occurred.", ex);
		} catch (LockTimeoutException ex) {
			ex.printStackTrace();
			throw new LockTimeoutException("Error accessing data: Lock timeout occurred.", ex);
		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new PersistenceException("Error accessing data: Persistence exception occurred.", ex);
		}
	}

}