package main.exceptions;

public class InSufficientStockException extends Exception {
	String message;

	public InSufficientStockException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
