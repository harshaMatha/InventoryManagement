package main.exceptions;

public class NoSuchUserException extends Exception {
	String message;

	public NoSuchUserException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
