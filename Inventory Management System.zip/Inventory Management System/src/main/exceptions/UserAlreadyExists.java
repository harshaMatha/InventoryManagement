package main.exceptions;

public class UserAlreadyExists extends Exception {
	String message;

	public UserAlreadyExists(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
