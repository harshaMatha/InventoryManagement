package main.models.loginModel.inputModels;

public class otpdetails {
	private String otpnumber;

	public otpdetails() {
		super();
	}

	public String getOtpnumber() {
		return otpnumber;
	}

	public void setOtpnumber(String otpnumber) {
		this.otpnumber = otpnumber;
	}

}
