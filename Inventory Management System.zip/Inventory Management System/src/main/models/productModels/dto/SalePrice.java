package main.models.productModels.dto;

public class SalePrice {

	private double salePrice;

	public SalePrice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalePrice(double salePrice) {
		super();
		this.salePrice = salePrice;
	}

	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

}
