package main.models.storeIssueModels.BLL;

import java.util.List;

import org.springframework.stereotype.Component;

import main.models.storeIssueModels.InputModels.StoreIssuesList;
import main.models.storeIssueModels.InputModels.StoreIssuesListData;

@Component
public class StoreIssuesBLL {
    public double calculateTotalPurchaseAmount(StoreIssuesList storeIssuesList) {
        double totalPurchaseAmount = 0.0;
        List<StoreIssuesListData> storeProducts = storeIssuesList.getStoreProducts();
        if (storeProducts != null) {
            for (StoreIssuesListData storeProduct : storeProducts) {
                totalPurchaseAmount += storeProduct.getPurchaseAmount();
            }
        }
        return totalPurchaseAmount;
    }
}

