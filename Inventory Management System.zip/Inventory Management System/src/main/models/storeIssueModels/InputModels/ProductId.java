package main.models.storeIssueModels.InputModels;

public class ProductId {
	int productId;

	public ProductId() {
		super();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

}
