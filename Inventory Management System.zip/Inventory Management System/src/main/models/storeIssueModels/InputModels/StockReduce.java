package main.models.storeIssueModels.InputModels;

public class StockReduce {
	int productId;
	int batchNo;
	int issuedQuantity;

	public StockReduce() {
		super();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(int batchNo) {
		this.batchNo = batchNo;
	}

	public int getIssuedQuantity() {
		return issuedQuantity;
	}

	public void setIssuedQuantity(int issuedQuantity) {
		this.issuedQuantity = issuedQuantity;
	}

	@Override
	public String toString() {
		return "StockReduce [productId=" + productId + ", batchNo=" + batchNo + ", issuedQuantity=" + issuedQuantity
				+ "]";
	}

}
