package main.models.storeIssueModels.InputModels;

public class StoreInfo {
	int storeId;
	double purchaseAmount;

	public StoreInfo() {
		super();
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public double getPurchaseAmount() {
		return purchaseAmount;
	}

	public void setPurchaseAmount(double purchaseAmount) {
		this.purchaseAmount = purchaseAmount;
	}

	@Override
	public String toString() {
		return "StoreInfo [storeId=" + storeId + ", purchaseAmount=" + purchaseAmount + "]";
	}

}
