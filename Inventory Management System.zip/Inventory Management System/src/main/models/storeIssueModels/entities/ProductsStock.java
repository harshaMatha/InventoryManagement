package main.models.storeIssueModels.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "im_Products_Stock")
public class ProductsStock implements Serializable {

	@Id
	@Column(name = "product_Id")
	private int productId;

	@Id
	@Column(name = "Batch_NO")
	private int batchNo;

	@Column(name = "Product_Stock")
	private int productStock;

	@Column(name = "Product_Sale_Price")
	private double productSalePrice;

	@Column(name = "Product_Cost")
	private double productCost;

	@Column(name = "Product_MRP")
	private double productMrp;

	public ProductsStock() {
		super();
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(int batchNo) {
		this.batchNo = batchNo;
	}

	public int getProductStock() {
		return productStock;
	}

	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}

	public double getProductSalePrice() {
		return productSalePrice;
	}

	public void setProductSalePrice(double productSalePrice) {
		this.productSalePrice = productSalePrice;
	}

	public double getProductCost() {
		return productCost;
	}

	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}

	public double getProductMrp() {
		return productMrp;
	}

	public void setProductMrp(double productMrp) {
		this.productMrp = productMrp;
	}

	@Override
	public String toString() {
		return "ProductsStock [productId=" + productId + ", batchNo=" + batchNo + ", productStock=" + productStock
				+ ", productSalePrice=" + productSalePrice + ", productCost=" + productCost + ", productMrp="
				+ productMrp + "]";
	}

	public ProductsStock(int productId, int batchNo, int productStock, double productSalePrice, double productCost,
			double productMrp) {
		super();
		this.productId = productId;
		this.batchNo = batchNo;
		this.productStock = productStock;
		this.productSalePrice = productSalePrice;
		this.productCost = productCost;
		this.productMrp = productMrp;
	}

}
