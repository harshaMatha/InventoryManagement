package main.models.storeIssueModels.entities;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "im_storeIssues")
public class StoreIssueModel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "storeissue_id")
	int storeIssueId;
	@Column(name = "storeIssue_date")
	LocalDate date = LocalDate.now();
	@Column(name = "amount")
	double purchaseAmount;
	@Column(name = "storeissue_status")
	String storeIssueStatus;
	@Column(name = "store_id")
	int storeId;
	@Column(name = "last_updated_user")
	String lastUpdatedUser;
	@Column(name = "last_updated_date")
	Date lastUpdatedDate;

	public StoreIssueModel() {
		super();
	}

	public int getStoreIssueId() {
		return storeIssueId;
	}

	public void setStoreIssueId(int storeIssueId) {
		this.storeIssueId = storeIssueId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getPurchaseAmount() {
		return purchaseAmount;
	}

	public void setPurchaseAmount(double purchaseAmount) {
		this.purchaseAmount = purchaseAmount;
	}

	public String getStoreIssueStatus() {
		return storeIssueStatus;
	}

	public void setStoreIssueStatus(String storeIssueStatus) {
		this.storeIssueStatus = storeIssueStatus;
	}

	public int getStoreId() {
		return storeId;
	}

	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public String toString() {
		return "StoreIssueModel [storeIssueId=" + storeIssueId + ", date=" + date + ", purchaseAmount=" + purchaseAmount
				+ ", storeIssueStatus=" + storeIssueStatus + ", storeId=" + storeId + ", lastUpdatedUser="
				+ lastUpdatedUser + ", lastUpdatedDate=" + lastUpdatedDate + "]";
	}

}
