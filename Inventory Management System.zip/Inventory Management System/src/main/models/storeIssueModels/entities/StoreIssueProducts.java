package main.models.storeIssueModels.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "im_storeissues_products")
public class StoreIssueProducts implements Serializable {

	public StoreIssueProducts(int storeIssueId, int productId, int batchNo, int issuedQuantity,
			StoreIssues storeIssues) {
		super();
		this.storeIssueId = storeIssueId;
		this.productId = productId;
		this.batchNo = batchNo;
		this.issuedQuantity = issuedQuantity;
		this.storeIssues = storeIssues;
	}

	@Id
	@Column(name = "storeIssue_id")
	int storeIssueId;
	@Id
	@Column(name = "product_id")
	int productId;
	@Id
	@Column(name = "batch_no")
	int batchNo;

	@Column(name = "quantity")
	int issuedQuantity;

	@ManyToOne()
	@JoinColumn(name = "storeIssue_id", referencedColumnName = "storeIssue_id", insertable = false, updatable = false)
	private StoreIssues storeIssues;

	public int getStoreIssueId() {
		return storeIssueId;
	}

	public void setStoreIssueId(int storeIssueId) {
		this.storeIssueId = storeIssueId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public StoreIssues getStoreIssues() {
		return storeIssues;
	}

	public void setStoreIssues(StoreIssues storeIssues) {
		this.storeIssues = storeIssues;
	}

	public int getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(int batchNo) {
		this.batchNo = batchNo;
	}

	public int getIssuedQuantity() {
		return issuedQuantity;
	}

	public void setIssuedQuantity(int issuedQuantity) {
		this.issuedQuantity = issuedQuantity;
	}

	@Override
	public String toString() {
		return "StoreIssueProducts [storeIssueId=" + storeIssueId + ", productId=" + productId + ", batchNo=" + batchNo
				+ ", issuedQuantity=" + issuedQuantity + "]";
	}

}
