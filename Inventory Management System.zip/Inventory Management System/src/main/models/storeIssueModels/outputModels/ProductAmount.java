package main.models.storeIssueModels.outputModels;

public class ProductAmount {
	double productSalePrice;

	public ProductAmount() {
		super();
	}

	public double getProductSalePrice() {
		return productSalePrice;
	}

	public void setProductSalePrice(double productSalePrice) {
		this.productSalePrice = productSalePrice;
	}

	@Override
	public String toString() {
		return "ProductAmount [productSalePrice=" + productSalePrice + "]";
	}

}
