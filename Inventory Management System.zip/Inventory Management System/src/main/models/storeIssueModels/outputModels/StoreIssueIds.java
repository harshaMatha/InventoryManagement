package main.models.storeIssueModels.outputModels;

public class StoreIssueIds {
	int storeIssueId;

	public int getStoreIssueId() {
		return storeIssueId;
	}

	public void setStoreIssueId(int storeIssueId) {
		this.storeIssueId = storeIssueId;
	}

	@Override
	public String toString() {
		return "StoreIssueIds [storeIssueId=" + storeIssueId + "]";
	}

	
}
