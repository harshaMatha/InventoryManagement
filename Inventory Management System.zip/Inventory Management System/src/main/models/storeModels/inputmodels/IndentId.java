package main.models.storeModels.inputmodels;

public class IndentId {

	private int indentId;

	public int getIndentId() {
		return indentId;
	}

	public void setIndentId(int indentId) {
		this.indentId = indentId;
	}
	
}
