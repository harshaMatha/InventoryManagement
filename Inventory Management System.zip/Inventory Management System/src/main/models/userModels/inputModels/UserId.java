package main.models.userModels.inputModels;

public class UserId {
int userId;

public UserId() {
	super();
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

}
