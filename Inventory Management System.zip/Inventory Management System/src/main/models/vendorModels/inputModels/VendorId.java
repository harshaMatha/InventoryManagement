package main.models.vendorModels.inputModels;

public class VendorId {

	int vendorId;

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

}
