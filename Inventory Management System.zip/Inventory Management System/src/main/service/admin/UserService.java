package main.service.admin;

import java.util.List;

import main.models.userModels.inputModels.UserTypeStatus;

public interface UserService {
	// Retrieves user filters based on the provided UserTypeStatus.
	List<UserTypeStatus> getUserFilters(UserTypeStatus userTypeStatus);

}
