package main.service.adminServiceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import main.dao.users.WarehouseUsersDAO;
import main.models.userModels.inputModels.UserTypeStatus;
import main.service.admin.UserService;

@Component
public class UserServiceImpl implements UserService {

	private final WarehouseUsersDAO userDao;
	private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	public UserServiceImpl(WarehouseUsersDAO userDao) {
		this.userDao = userDao;
	}

	// Getting filter data from database
	@Override
	public List<UserTypeStatus> getUserFilters(UserTypeStatus userTypeStatus) {
		List<UserTypeStatus> usersList = null;
		if (userTypeStatus.getUserType().length() > 0) {
			if (userTypeStatus.getUserStatus().length() > 0) {
				usersList = userDao.getUserByTypeStatus(userTypeStatus);
			} else {
				usersList = userDao.getFilteredDataByType(userTypeStatus);
			}
		} else {
			usersList = userDao.getFilteredDataByStatus(userTypeStatus);
		}

		// Logging the user filter result
		logger.info("User filter result: {}", usersList);

		return usersList;
	}
}
