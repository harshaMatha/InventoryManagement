package main.service.inventory;

import java.util.List;

import main.models.storeIssueModels.inputModels.StoreFilters;
import main.models.storeIssueModels.outputModels.StoreIssuesData;

public interface StoreIssueService {
	// Retrieves store issues based on the provided filters.
	List<StoreIssuesData> getStoreIssuesFilters(StoreFilters storeFilters) throws Exception;

}
