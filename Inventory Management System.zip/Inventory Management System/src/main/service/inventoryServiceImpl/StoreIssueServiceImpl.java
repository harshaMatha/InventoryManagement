package main.service.inventoryServiceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import main.dao.storeIssues.StoreIssueDao;
import main.models.storeIssueModels.inputModels.StoreFilters;
import main.models.storeIssueModels.outputModels.StoreIssuesData;
import main.service.inventory.StoreIssueService;

@Component
public class StoreIssueServiceImpl implements StoreIssueService {

	private static final Logger logger = LoggerFactory.getLogger(StoreIssueServiceImpl.class);

	private final StoreIssueDao storeIssuesDao;

	@Autowired
	public StoreIssueServiceImpl(StoreIssueDao storeIssuesDao) {
		this.storeIssuesDao = storeIssuesDao;
	}

	@Override
	public List<StoreIssuesData> getStoreIssuesFilters(StoreFilters storeFilters) throws Exception {
		List<StoreIssuesData> storeIssues = null;
		if (storeFilters.getStoreId() != 0) {
			if (storeFilters.getStoreIssueStatus().length() > 0) {
				if (storeFilters.getFromDate() != null) {
					// Fetching store issues by filter data with store ID, issue status, and from date
					storeIssues = storeIssuesDao.getStoreIssuesListByIdStatusFrom(storeFilters);
				} else {
					// Fetching store issues by filter data with store ID and issue status
					storeIssues = storeIssuesDao.getStoreIssuesListByIdStatus(storeFilters);
				}
			} else {
				if (storeFilters.getFromDate() != null) {
					// Fetching store issues by filter data with store ID and from date
					storeIssues = storeIssuesDao.getStoreIssuesListByIdFrom(storeFilters);
				} else {
					// Fetching store issues by filter data with store ID
					storeIssues = storeIssuesDao.getStoreIssuesListById(storeFilters);
				}
			}
		} else {
			if (storeFilters.getStoreIssueStatus().length() > 0) {
				if (storeFilters.getFromDate() != null) {
					// Fetching store issues by filter data with issue status and from date
					storeIssues = storeIssuesDao.getStoreIssuesListByStatusFrom(storeFilters);
				} else {
					// Fetching store issues by filter data with issue status
					storeIssues = storeIssuesDao.getStoreIssuesListByStatus(storeFilters);
				}
			} else {
				if (storeFilters.getFromDate() != null) {
					// Fetching store issues by filter data with from date
					storeIssues = storeIssuesDao.getStoreIssuesListByFrom(storeFilters);
				} else {
					// Fetching store issues by filter data with to date
					storeIssues = storeIssuesDao.getStoreIssuesListByTo(storeFilters);
				}
			}
		}

		logger.info("Retrieved {} store issues based on filters: {}", storeIssues.size(), storeFilters);
		return storeIssues;
	}

}
