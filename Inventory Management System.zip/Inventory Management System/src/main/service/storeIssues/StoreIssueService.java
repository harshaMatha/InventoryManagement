// package main.service.storeIssues;
//
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Service;
//
// import main.dal.storeIndents.StoreIndentsDal;
//
// @Service
// public class StoreIssueService {
//
// @Autowired
// private StoreIndentsDal storeIndentsDal;
//
// public double calculateTotalPurchaseAmount(List<ProductData> productsData) {
// double totalPurchaseAmount = 0;
// for (ProductData productData : productsData) {
// totalPurchaseAmount += Double.parseDouble(productData.getPurchaseAmount());
// }
// return totalPurchaseAmount;
// }
//
// public void saveStoreIssue(String storeId, double totalPurchaseAmount) {
// StoreIssue storeIssue = new StoreIssue();
// storeIssue.setStoreId(storeId);
// storeIssue.setPurchaseAmount(totalPurchaseAmount);
//
// stockDAO.saveStoreIssue(storeIssue);
// }
// }
