package main.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import main.dao.storeissues.StoreIssuesDAO;
import main.models.indentModels.Indents;

@Controller
public class StoreIssuesController {

	@Autowired
	public StoreIssuesDAO s;

	@GetMapping("/createStockIssueButton")
	public String saveIndent(Indents indent, Model model) {
		s.createIndent(indent);
		return "inventory/createStockIssues";
	}

	@GetMapping("/indentsButton")
	public String createVendor(Model m) {
		m.addAttribute("indents", p.getAllIndents());
		return "inventory/stockIssues";
	}

}
