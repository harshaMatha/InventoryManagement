package main.controllers;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.dao.users.WarehouseUsersDAO;
import main.dto.users.UserDto;
import main.models.userModels.entities.User;
import main.models.userModels.inputModels.UserData;
import main.models.userModels.outputModels.UserInfo;

@Controller
public class UserController {

	@Autowired
	public WarehouseUsersDAO userDAO;

	@Autowired
	ModelMapper mapper;

	@PostMapping("/saveUser")
	public String saveUser(@RequestBody String data, Model model) {
		UserData userData = null;
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			userData = objectMapper.readValue(data, UserData.class);
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		User s = mapper.map(userData, User.class);
		userDAO.saveUser(s);
		return "admin/adminHome";

	}

	@GetMapping("/showUsers")
	public String createUser(Model m) {
		System.out.println("Hiii");
		List<User> users = userDAO.getAllUsers();
		List<UserInfo> ui = new ArrayList();
		for (User u : users) {
			ui.add(mapper.map(u, UserInfo.class));
		}
		m.addAttribute("users", ui);
		return "admin/userData";
	}

	@RequestMapping(value = "/getUserData", method = RequestMethod.POST)
	@ResponseBody
	public User getUserData(@RequestBody UserDto v) {
		User user = userDAO.getUserData(v);
		return user;
	}

	@GetMapping("/editProfile")
	public String showEditProfileForm(Model model) {
		User admin = userDAO.getAdmin();
		model.addAttribute("admin", admin);
		return "editProfile";
	}

	@PostMapping("/editProfile")
	public ResponseEntity<String> saveProfile(@RequestBody User updatedUser) {
		User admin = userDAO.getAdmin();
		if (admin == null) {
			return ResponseEntity.badRequest().body("Admin not found");
		}
		// Update the admin object with the new data
		admin.setUserName(updatedUser.getUserName());
		admin.setUserPassword(updatedUser.getUserPassword());
		// Save the updated admin
		userDAO.saveUser(admin);
		return ResponseEntity.ok("Profile updated successfully");
	}
}
