package main.dao.login;

import org.springframework.stereotype.Component;

import main.models.loginModel.Login;

@Component
public class LoginDAO {

	public boolean login(Login login) {
		return true;

	}

}
