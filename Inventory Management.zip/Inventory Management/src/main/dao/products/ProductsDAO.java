package main.dao.products;


import java.util.List;

import main.models.productsModels.ProductStockData;


public interface ProductsDAO {
	
	public List<ProductStockData> getReOrderLevelProducts();
	public List<ProductStockData> getProductsByCategory(int selectedCategoryId);
	
	public List<ProductStockData> getProductsByProductId(int selectedProductId);
	
	public ProductStockData getQuantityandpriceByProductIdOrBatchNo(int selectedProductId,int selectedBatchNo);

	
}
