package main.dao.storeissues;

public class StoreIssuesDAO {

}
