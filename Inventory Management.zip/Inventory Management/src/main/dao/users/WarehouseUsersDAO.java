package main.dao.users;

import java.util.List;

import main.dto.users.UserDto;
import main.models.userModels.entities.User;

public interface WarehouseUsersDAO {
	public void saveUser(User user);

	public List<User> getAllUsers();

	public User getUserData(UserDto v);

	public User deleteUser(User user);

	public List<User> getAllActiveUsers();

	public User getAdmin();

}
