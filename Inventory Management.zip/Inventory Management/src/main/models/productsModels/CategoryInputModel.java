package main.models.productsModels;

public class CategoryInputModel {
    private int categoryId;

    
    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
}