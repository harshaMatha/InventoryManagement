package main.models.productsModels;

public class VendorInputModel {

}
