package main.models.storeModels.inputmodels;

public class StoreId {
	int StoreId;

	public StoreId() {
		super();
	}

	public int getStoreId() {
		return StoreId;
	}

	public void setStoreId(int storeId) {
		StoreId = storeId;
	}
	

}
