package main.bll.procurement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import main.dao.products.ProductsDAO;
import main.models.productModels.dto.ProductPrice;
import main.models.productModels.dto.ProductProfit;
import main.models.productModels.dto.SalePrice;
import main.models.productModels.inputModels.ProductsProductIdInputModel;

@Component
public class GrnBll {

	@Autowired
	ProductsDAO pd;

	public SalePrice getProductSalePrice(ProductPrice pp) {

		ProductsProductIdInputModel p = new ProductsProductIdInputModel(pp.getProductId());
		ProductProfit productProfit = pd.getProfitPercentage(p);
		double unitPrice = pp.getCostPrice() / pp.getQuantity();

		double salePrice = unitPrice + ((unitPrice * productProfit.getProfitPercentage()) / 100);

		SalePrice s = new SalePrice(salePrice);
		return s;

	}
}
