package Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FirstController {

	@RequestMapping(value = "/")
	public String getvendor() {
		return "views/addvendor";
	}

	@RequestMapping(value = "/adduser")
	public String getuser() {
		return "views/addusers";
	}

	@RequestMapping(value = "/addstore")
	public String getstore() {
		return "views/addstore";
	}

	@RequestMapping(value = "/productcateogery")
	public String getproductcateogery() {
		return "views/productcateogery";
	}

	@RequestMapping(value = "/deletevendor")
	public String getdeletevendor() {
		return "views/deletevendor";
	}

	@RequestMapping(value = "/deletestore")
	public String getdeletestore() {
		return "views/deletestore";
	}

	@RequestMapping(value = "/deleteuser")
	public String getdeleteuser() {
		return "views/deleteuser";
	}

	@RequestMapping(value = "/updatevendor")
	public String getupdatevendor() {
		return "views/updatevendor";
	}
}
