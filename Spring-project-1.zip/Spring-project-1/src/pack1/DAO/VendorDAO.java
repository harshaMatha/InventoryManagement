package pack1.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pack1.models.Vendor;

@Repository
@Transactional
public class VendorDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public int addVendor(Vendor v) {
		entityManager.persist(v);
		return v.getVendorId();
	}
}
