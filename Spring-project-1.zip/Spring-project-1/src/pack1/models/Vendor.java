package pack1.models;

public class Vendor {
	private int vendorId;
	private String vendorName;
	private String vendorAddress;
	private int vendorPhonenumber;
	private String vendorStatus;

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public int getVendorPhone() {
		return vendorPhonenumber;
	}

	public void setVendorPhone(int vendorPhone) {
		this.vendorPhonenumber = vendorPhone;
	}

	public String getVendorStatus() {
		return vendorStatus;
	}

	public void setVendorStatus(String vendorStatus) {
		this.vendorStatus = vendorStatus;
	}

}
