package pack1.DAO;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import pack1.models.Book;

public class BookDAO {

	JdbcTemplate temp;

	public BookDAO(DataSource datasource) {
		temp = new JdbcTemplate(datasource);
	}

	public List<Book> getDetails() {
		// TODO Auto-generated method stub
		return temp.query("select * from libdata", new LibraryMapper());

	}

	public int addBooks(Book b) {
		return temp.update("insert into libdata values(?,?,?)", b.getBookid(), b.getBookname(), b.getCost());
	}

	public int deleteBooks(int bookid) {
		return temp.update("delete from libdata where bookid=?", bookid);
	}

	public int updateBooks(Book b) {
		return temp.update("update libdata set bookname=?,cost=? where bookid=?", b.getBookname(), b.getCost(),
				b.getBookid());
	}

	public List<Book> getBooks(int bookid) {
		return temp.query("select * from libdata where bookid=?", new Object[] { bookid }, new LibraryMapper());
	}

}
