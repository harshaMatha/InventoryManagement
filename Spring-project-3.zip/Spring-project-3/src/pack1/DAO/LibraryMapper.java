package pack1.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import pack1.models.Book;

public class LibraryMapper implements RowMapper<Book> {

	@Override
	public Book mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Book b = new Book();
		b.setBookid(rs.getInt("bookid"));
		b.setBookname(rs.getString("bookname"));
		b.setCost(rs.getDouble("cost"));

		return b;

	}

}
