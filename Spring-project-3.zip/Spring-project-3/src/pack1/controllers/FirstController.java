package pack1.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import pack1.DAO.BookDAO;
import pack1.models.Book;

@Controller
public class FirstController {
	BookDAO bookDao;

	public FirstController(BookDAO bookDao) {
		this.bookDao = bookDao;
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String getBooks(Model m) {
		List<Book> l = bookDao.getDetails();
		m.addAttribute("data", l);
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "log";
	}

	@RequestMapping(value = "/index2", method = RequestMethod.GET)
	public String addBooks(Model m) {
		return "bookDetails";
	}

	@RequestMapping(value = "/index3", method = RequestMethod.GET)
	public String saveBooks(Book b, Model m) {
		bookDao.addBooks(b);
		String h = "Book added Successfully";
		m.addAttribute("hk", h);
		return "bookInfo";
	}

	@RequestMapping(value = "/index4", method = RequestMethod.GET)
	public String deleteBooks() {
		return "deleteBook";
	}

	@RequestMapping(value = "/index5", method = RequestMethod.GET)
	public String deleteBooks(@RequestParam("bookid") int bookid, Model m) {
		bookDao.deleteBooks(bookid);
		String h = "Book Deleted Successfully";
		m.addAttribute("h", h);
		return "bookInfo";
	}

	@RequestMapping(value = "/index6", method = RequestMethod.GET)
	public String updatingBooks() {
		return "updateDetails";
	}

	@RequestMapping(value = "/index7", method = RequestMethod.GET)
	public String updateBooks(Book b, Model m) {
		bookDao.updateBooks(b);
		String a = "Book updated Sucessfully";
		m.addAttribute("b", a);
		return "bookInfo";
	}

	@RequestMapping(value = "/index8", method = RequestMethod.GET)
	public String getBooks() {
		return "getBooks";
	}

	@RequestMapping(value = "/index1", method = RequestMethod.GET)
	public String getBooks(@RequestParam("bookid") int bookid, Model m) {
		List<Book> l = bookDao.getBooks(bookid);
		m.addAttribute("k", l);
		return "login2";
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String homePage() {
		return "home";
	}

}
