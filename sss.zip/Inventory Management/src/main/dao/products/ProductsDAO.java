package main.dao.products;


import java.util.List;

import main.models.adminModels.ProductsCategory;
import main.models.productsModels.HSNEntityModel;
import main.models.productsModels.ProductStockData;


public interface ProductsDAO {
	
	public List<ProductStockData> getReOrderLevelProducts();
	public List<ProductStockData> getProductsByCategory(int selectedCategoryId);
	
	public List<ProductStockData> getProductsByProductId(int selectedProductId);
	
	public ProductStockData getQuantityandpriceByProductIdOrBatchNo(int selectedProductId,int selectedBatchNo);
	public boolean saveCategory(ProductsCategory productsCategory);
	public boolean saveHSN(HSNEntityModel hsnEntityModel);
	

	
}
