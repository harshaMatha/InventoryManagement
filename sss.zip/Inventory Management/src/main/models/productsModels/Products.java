package main.models.productsModels;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "im_Products")
public class Products {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Product_ID")
    private int productId;

    @Column(name = "Product_Name")
    private String productName;

    @Column(name = "product_category_id")
    private int category;
    
    @Column(name="product_reorder_level")
    private int productReOrderLevel;
    
    @Column(name="product_hsn_code")
    private int productHsnCode;
    
	public int getProductReOrderLevel() {
		return productReOrderLevel;
	}


	public void setProductReOrderLevel(int productReOrderLevel) {
		this.productReOrderLevel = productReOrderLevel;
	}


	public int getProductHsnCode() {
		return productHsnCode;
	}


	public void setProductHsnCode(int productHsnCode) {
		this.productHsnCode = productHsnCode;
	}


	// Fields from im_Products_Stock table
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private List<ProductStock> productStocks;


	public int getCategory() {
		return category;
	}


	public void setCategory(int category) {
		this.category = category;
	}


	public Products() {
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}




	public List<ProductStock> getProductStocks() {
		return productStocks;
	}


	public void setProductStocks(List<ProductStock> productStocks) {
		this.productStocks = productStocks;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


    

    
    
}
