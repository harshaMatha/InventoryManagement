package main.models.productsModels;

public class ProductsProductIdInputModel {

 private int productId;



public int getProductId() {
	return productId;
}

public void setProductId(int productId) {
	this.productId = productId;
}

}