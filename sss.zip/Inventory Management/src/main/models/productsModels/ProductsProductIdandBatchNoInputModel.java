package main.models.productsModels;

public class ProductsProductIdandBatchNoInputModel {
	private int productId;
	private int batchNo;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(int batchNo) {
		this.batchNo = batchNo;
	}
	

}
