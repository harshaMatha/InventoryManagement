package main.models.statisticsModels;

public class Products {

	
private String ProductName;
private int ProductId;
public String getProductName() {
	return ProductName;
}
public void setProductName(String productName) {
	ProductName = productName;
}
public int getProductId() {
	return ProductId;
}
public void setProductId(int productId) {
	ProductId = productId;
}
public Products(String productName, int productId) {
	super();
	ProductName = productName;
	ProductId = productId;
}
	

}
